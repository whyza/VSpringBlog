'use strict'
module.exports = {
  NODE_ENV: '"production"',
  // BASE_API: '"https://iazuresky.com:8443/"',
    BASE_API: '"http://localhost:8081/"',

}
